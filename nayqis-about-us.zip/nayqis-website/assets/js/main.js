// Interaksi sederhana untuk website Nayqis
document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");

  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", () => {
      const isOpen = navLinks.classList.toggle("open");
      menuToggle.setAttribute("aria-expanded", String(isOpen));
      menuToggle.setAttribute(
        "aria-label",
        isOpen ? "Tutup menu navigasi" : "Buka menu navigasi"
      );
    });

    // Tutup menu setelah pengunjung memilih tautan di layar kecil.
    navLinks.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => {
        navLinks.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Buka menu navigasi");
      });
    });

    // Jika jendela diperbesar kembali ke desktop, reset menu mobile.
    window.addEventListener("resize", () => {
      if (window.innerWidth > 680) {
        navLinks.classList.remove("open");
        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Buka menu navigasi");
      }
    });
  }

  // Tahun footer selalu mengikuti tahun saat ini.
  const year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();
});
