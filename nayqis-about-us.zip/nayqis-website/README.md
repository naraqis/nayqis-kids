# Nayqis Website

## Struktur
- `index.html` — halaman Home
- `about.html` — halaman About Us (cerita, visi-misi, dan perkenalan tim)
- `assets/css/style.css` — stylesheet
- `assets/js/main.js` — JavaScript untuk menu responsif dan tahun footer

## Menjalankan
1. Ekstrak ZIP.
2. Buka folder ini di Visual Studio Code.
3. Jalankan `index.html` dengan ekstensi Live Server.

Foto dan font dimuat dari layanan eksternal, sehingga memerlukan koneksi internet.
Nama dan jabatan tim pada halaman About Us adalah contoh dan dapat diedit sesuai data perusahaan sebenarnya.
